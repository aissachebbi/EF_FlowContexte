package com.bnpparibas.frmk.easyflow.si.mq2db.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApplicationParameterDao {

    public static final class AppParamRow {
        public final String key;
        public final String value;
        public final long versionNum;
        public final Instant updatingDate;
        public final Instant creationDate;

        public AppParamRow(String key, String value, long versionNum, Instant updatingDate, Instant creationDate) {
            this.key = key;
            this.value = value;
            this.versionNum = versionNum;
            this.updatingDate = updatingDate;
            this.creationDate = creationDate;
        }

        public Instant lastChangeInstant() {
            return updatingDate != null ? updatingDate : creationDate;
        }
    }

    public static final class Fingerprint {
        public final long maxVersion;
        public final Instant lastChange;

        public Fingerprint(long maxVersion, Instant lastChange) {
            this.maxVersion = maxVersion;
            this.lastChange = lastChange;
        }
    }

    private final JdbcTemplate jdbc;

    public ApplicationParameterDao(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Map<String, AppParamRow> loadByKeyPrefix(String keyPrefix) {
        String sql =
                "select ap.KEY, ap.VALUE, ap.VERSION_NUM, ap.UPDATING_DATE, ap.CREATION_DATE " +
                        "from ACETP.APPLICATION_PARAMETER ap " +
                        "where ap.KEY like ?";

        List<AppParamRow> rows = jdbc.query(sql, ps -> ps.setString(1, keyPrefix + "%"), (rs, rowNum) -> {
            Timestamp upd = rs.getTimestamp("UPDATING_DATE");
            Timestamp cre = rs.getTimestamp("CREATION_DATE");
            return new AppParamRow(
                    rs.getString("KEY"),
                    rs.getString("VALUE"),
                    rs.getLong("VERSION_NUM"),
                    upd != null ? upd.toInstant() : null,
                    cre != null ? cre.toInstant() : null
            );
        });

        Map<String, AppParamRow> byBranch = new HashMap<>();
        for (AppParamRow r : rows) {
            String branchCode = extractBranchCode(keyPrefix, r.key);
            byBranch.put(branchCode, r);
        }
        return byBranch;
    }

    public Fingerprint fingerprint(String keyPrefix) {
        String sql =
                "select max(ap.VERSION_NUM) as MAX_VERSION, " +
                        "       max(nvl(ap.UPDATING_DATE, ap.CREATION_DATE)) as LAST_CHANGE " +
                        "from ACETP.APPLICATION_PARAMETER ap " +
                        "where ap.KEY like ?";

        return jdbc.queryForObject(sql, ps -> ps.setString(1, keyPrefix + "%"), (rs, rowNum) -> {
            long maxV = rs.getLong("MAX_VERSION");
            Timestamp ts = rs.getTimestamp("LAST_CHANGE");
            Instant last = ts != null ? ts.toInstant() : Instant.EPOCH;
            return new Fingerprint(maxV, last);
        });
    }

    private static String extractBranchCode(String keyPrefix, String fullKey) {
        if (fullKey != null && fullKey.startsWith(keyPrefix)) {
            return fullKey.substring(keyPrefix.length());
        }
        // fallback: dernier token après underscore
        if (fullKey == null) return "";
        int idx = fullKey.lastIndexOf('_');
        return idx >= 0 ? fullKey.substring(idx + 1) : fullKey;
    }
}
