package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

public final class BranchParameters {
    private final boolean fileMode;
    private final int messageThreshold;
    private final long timeThresholdMs;
    private final Map<String, String> extra;

    public BranchParameters(boolean fileMode, int messageThreshold, long timeThresholdMs, Map<String, String> extra) {
        this.fileMode = fileMode;
        this.messageThreshold = messageThreshold;
        this.timeThresholdMs = timeThresholdMs;
        this.extra = Collections.unmodifiableMap(Objects.requireNonNull(extra, "extra"));
    }

    public boolean isFileMode() { return fileMode; }
    public int getMessageThreshold() { return messageThreshold; }
    public long getTimeThresholdMs() { return timeThresholdMs; }
    public Map<String, String> getExtra() { return extra; }
}
