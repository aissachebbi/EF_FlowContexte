package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class BranchParametersParser {

    private BranchParametersParser() {}

    public static BranchParameters parse(String raw) {
        boolean fileMode = true;
        int messages = 0;
        long timeMs = 0L;

        Map<String, String> extra = new HashMap<>();
        if (raw == null) return new BranchParameters(fileMode, messages, timeMs, extra);

        String s = raw.trim();
        if (s.isEmpty()) return new BranchParameters(fileMode, messages, timeMs, extra);

        String[] parts = s.split(",");
        for (String part : parts) {
            String p = part.trim();
            if (p.isEmpty() || "*".equals(p)) continue;

            String[] kv = p.split(":", 2);
            if (kv.length != 2) {
                extra.put(p, "");
                continue;
            }

            String key = kv[0].trim();
            String val = kv[1].trim();

            String k = key.toLowerCase(Locale.ROOT);
            if ("filemode".equals(k)) {
                fileMode = Boolean.parseBoolean(val);
            } else if ("messages".equals(k) || "messagethreshold".equals(k) || "message".equals(k)) {
                messages = parseIntSafe(val, 0);
            } else if ("time".equals(k) || "timethreshold".equals(k)) {
                timeMs = parseDurationToMs(val);
            } else {
                extra.put(key, val);
            }
        }

        return new BranchParameters(fileMode, messages, timeMs, extra);
    }

    private static int parseIntSafe(String v, int def) {
        try { return Integer.parseInt(v.trim()); }
        catch (Exception e) { return def; }
    }

    /**
     * Durée -> ms:
     * - "250ms" => 250
     * - "2s" / "2sec" => 2000
     * - "2min" => 120000
     * - "120" (sans unité) => secondes => 120000
     */
    private static long parseDurationToMs(String v) {
        String s = v.trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return 0L;

        try {
            if (s.endsWith("ms")) return Long.parseLong(s.substring(0, s.length() - 2).trim());
            if (s.endsWith("sec")) return Long.parseLong(s.substring(0, s.length() - 3).trim()) * 1000L;
            if (s.endsWith("s")) return Long.parseLong(s.substring(0, s.length() - 1).trim()) * 1000L;
            if (s.endsWith("min")) return Long.parseLong(s.substring(0, s.length() - 3).trim()) * 60_000L;
            if (s.endsWith("h")) return Long.parseLong(s.substring(0, s.length() - 1).trim()) * 3_600_000L;

            // Sans unité => secondes
            return Long.parseLong(s) * 1000L;
        } catch (Exception e) {
            return 0L;
        }
    }
}
