# Conventions de Parsing du champ APPLICATION_PARAMETER.VALUE

Ce document définit les règles de conversion utilisées lors de la lecture de la colonne `VALUE` de la table `APPLICATION_PARAMETER`. La valeur est une chaîne de caractères formatée en `clé:valeur` séparées par des virgules.

---

## 1. Exemples de format
Le champ `VALUE` peut contenir plusieurs paramètres techniques. Voici des exemples types rencontrés en base :

*   `*,fileMode:true,messages:100,time:2min,neverPaused:true`
*   `*,fileMode:true,timeThreshold:120,messageThreshold:1500`

---

## 2. Règles de conversion des types

Le parseur (`BranchParametersParser`) applique des règles strictes pour convertir les chaînes de caractères en types Java exploitables.

### Valeurs Booléennes
*   `fileMode` → Converti en `boolean`.
*   Toute clé se terminant par `Enabled` ou commençant par `is` ou `never` est généralement traitée comme un booléen.

### Valeurs Entières (Comptage)
Les clés suivantes sont converties en `int` :
*   `messages`
*   `messageThreshold`
*   `message`

### Seuils de Temps (Durées)
Les clés `time` et `timeThreshold` sont converties en une durée en **millisecondes (ms)** selon les suffixes suivants :

| Suffixe | Exemple | Résultat (ms) |
| :--- | :--- | :--- |
| `ms` | `250ms` | `250` |
| `s`, `sec` | `2s` | `2000` |
| `min` | `2min` | `120000` |
| *(aucun)* | `120` | `120000` (interprété par défaut en **secondes**) |

> **Note :** L'interprétation par défaut en secondes (quand l'unité est absente) est conservée pour des raisons d'héritage avec les anciens systèmes de configuration.

---

## 3. Gestion des paramètres inconnus

Tous les jetons (tokens) qui ne correspondent pas à une règle de conversion explicite ci-dessus sont stockés tels quels dans une structure de données `extra` (Map de chaînes de caractères). Cela permet d'étendre la configuration sans modifier le parseur principal.