# Spécification Technique : Table ACETP.FLOW_DEFINITION

Ce document décrit la structure et l'utilisation de la table `ACETP.FLOW_DEFINITION`, qui sert de référentiel central pour la gestion des flux dans le **Flow Registry**.

---

## 1. Objectif du Registry

Le **Flow Registry** est chargé au démarrage de l'application (startup) sans dépendre de Spring Boot ou JPA/Hibernate. Il s'appuie sur trois sources de données principales :
*   **`ACETP.FLOW_DEFINITION`** : Liste et configuration globale des flux gérés.
*   **`CB_FILE_TYPE`** : Détermine le type de fichier unique par branche pour un flux donné (via un pattern de filtrage).
*   **`ACETP.APPLICATION_PARAMETER`** : Contient la configuration spécifique (clé/valeur) par couple (flux, branche).

### Capacités attendues :
- Exposition d'une structure en mémoire : `Map<String, FlowContext>`.
- Support du **Hot Reload** ciblé par flux lors de modifications dans `APPLICATION_PARAMETER`.
- Indépendance vis-à-vis de Spring Integration (couplage ultérieur).

---

## 2. Modèle de Données et Règles Fonctionnelles

### Cardinalités et Relations
Pour un flux défini par un pattern (ex: `'%MTMIN%'`) :

1.  **Filtrage des Filetypes** : La table `CB_FILE_TYPE` fournit les types de fichiers actifs (`RUNNING_STATUS_IND = 1`) dont le `PHYSICAL_FILE_TYPE` correspond au pattern.
2.  **Lien avec les Branches** : Chaque type de fichier est rattaché à une branche unique (`CB_FILE_TYPE.BRANCH_DB_ID` → `BRANCH.CODE`).
3.  **Contrainte d'Unicité** : Pour un pattern de flux donné, il doit y avoir une relation **1 Branche ⇔ 1 Filetype**.
4.  **Configuration applicative** :
    - `APPLICATION_PARAMETER` porte la configuration dans le champ `VALUE` (format `key1:val1,key2:val2,...`).
    - La recherche s'effectue par clé (`KEY`). Si aucune ligne spécifique à la branche n'est trouvée, une clé par défaut `*` peut être utilisée.

---

## 3. Structure de la Table (DDL)

### Définition des colonnes
| Colonne | Type | Contrainte | Description |
| :--- | :--- | :--- | :--- |
| `FLOW_NAME` | `VARCHAR2(30)` | `PRIMARY KEY` | Nom unique du flux. |
| `BUSINESS_TABLE_NAME` | `VARCHAR2(64)` | `NOT NULL` | Table cible pour les données métier. |
| `FILETYPE_PHYSICAL_PATTERN` | `VARCHAR2(200)` | `NOT NULL` | Pattern pour filtrer `CB_FILE_TYPE` (ex: `%MTMIN%`). |
| `APP_PARAM_KEY_PREFIX` | `VARCHAR2(80)` | `NOT NULL` | Préfixe de clé dans `APPLICATION_PARAMETER`. |
| `ENABLED` | `NUMBER(1)` | `DEFAULT 1` | Activation globale du flux. |
| `RELOAD_ENABLED` | `NUMBER(1)` | `DEFAULT 1` | Autorisation du rechargement à chaud. |
| `VERSION_NUM` | `NUMBER` | `DEFAULT 1` | Numéro de version pour la détection de changements. |
| `CREATION_DATE` | `DATE` | `DEFAULT SYSDATE` | Date de création de l'enregistrement. |
| `UPDATING_DATE` | `DATE` | - | Date de dernière mise à jour. |
| `NARRATIVE` | `VARCHAR2(1000)`| - | Commentaire ou description libre. |

### Script DDL
```sql
-- Référentiel des flux gérés par le registry
CREATE TABLE ACETP.FLOW_DEFINITION (
  FLOW_NAME                 VARCHAR2(30)   NOT NULL,
  BUSINESS_TABLE_NAME       VARCHAR2(64)   NOT NULL,
  FILETYPE_PHYSICAL_PATTERN VARCHAR2(200)  NOT NULL,
  APP_PARAM_KEY_PREFIX      VARCHAR2(80)   NOT NULL,
  ENABLED                   NUMBER(1)      DEFAULT 1 NOT NULL,
  RELOAD_ENABLED            NUMBER(1)      DEFAULT 1 NOT NULL,
  VERSION_NUM               NUMBER         DEFAULT 1 NOT NULL,
  CREATION_DATE             DATE           DEFAULT SYSDATE NOT NULL,
  UPDATING_DATE             DATE,
  NARRATIVE                 VARCHAR2(1000),

  CONSTRAINT PK_FLOW_DEFINITION PRIMARY KEY (FLOW_NAME)
);

-- Index pour optimiser le scan du poller
CREATE INDEX ACETP.I_FLOW_DEF_ENABLED
  ON ACETP.FLOW_DEFINITION(ENABLED, RELOAD_ENABLED);
```

---

## 4. Initialisation (Exemple : MTMIN)

L'exemple suivant montre comment insérer un nouveau flux. 

> **Important :** Le préfixe `APP_PARAM_KEY_PREFIX` combiné au code de la branche doit permettre de reconstruire exactement la clé présente dans `APPLICATION_PARAMETER.KEY`.

```sql
INSERT INTO ACETP.FLOW_DEFINITION (
  FLOW_NAME, BUSINESS_TABLE_NAME, FILETYPE_PHYSICAL_PATTERN, APP_PARAM_KEY_PREFIX,
  ENABLED, RELOAD_ENABLED, VERSION_NUM, NARRATIVE
) VALUES (
  'MTMIN', 'CL_BUSINESS_MTM_IN', '%MTMIN%', 'EZF_MQ2FILE_FLUSH_MTMIN_',
  1, 1, 1, 'Flow MTM IN - configuration MQ2 file (flush) par branche'
);

COMMIT;
```

---

## 5. Requêtes SQL de Vérification

### 1) Vérifier l'unicité (1 branche ↔ 1 filetype)
Permet de s'assurer qu'un pattern ne retourne pas plusieurs filetypes pour la même branche.
```sql
SELECT b.code AS branch_code, COUNT(*) AS nb_filetypes
FROM CB_FILE_TYPE cft
JOIN ACETP.BRANCH b ON cft.BRANCH_DB_ID = b.BRANCH_DB_ID
WHERE cft.RUNNING_STATUS_IND = 1
  AND UPPER(cft.PHYSICAL_FILE_TYPE) LIKE UPPER('%MTMIN%')
GROUP BY b.code
HAVING COUNT(*) <> 1;
```

### 2) Lister les paramètres configurés
```sql
SELECT *
FROM ACETP.APPLICATION_PARAMETER ap
WHERE ap.key LIKE 'EZF_MQ2FILE_FLUSH_MTMIN_%';
```

### 3) Fingerprint (Détection de changement pour le Poller)
Requête utilisée par le mécanisme de rechargement à chaud pour détecter une modification.
```sql
SELECT
  MAX(ap.version_num) AS max_version,
  MAX(NVL(ap.updating_date, ap.creation_date)) AS last_change
FROM ACETP.APPLICATION_PARAMETER ap
WHERE ap.key LIKE 'EZF_MQ2FILE_FLUSH_MTMIN_%';
```