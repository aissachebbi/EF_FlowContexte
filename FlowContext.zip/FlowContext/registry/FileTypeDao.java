package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import java.util.Objects;

public final class FileTypeDao {
    private final String branchCode;
    private final long branchDbId;
    private final long cbFileTypeDbId;
    private final String physicalFileType;
    private final BranchParameters parameters;

    public FileTypeDao(
            String branchCode,
            long branchDbId,
            long cbFileTypeDbId,
            String physicalFileType,
            BranchParameters parameters
    ) {
        this.branchCode = Objects.requireNonNull(branchCode, "branchCode");
        this.branchDbId = branchDbId;
        this.cbFileTypeDbId = cbFileTypeDbId;
        this.physicalFileType = Objects.requireNonNull(physicalFileType, "physicalFileType");
        this.parameters = Objects.requireNonNull(parameters, "parameters");
    }

    public String getBranchCode() { return branchCode; }
    public long getBranchDbId() { return branchDbId; }
    public long getCbFileTypeDbId() { return cbFileTypeDbId; }
    public String getPhysicalFileType() { return physicalFileType; }
    public BranchParameters getParameters() { return parameters; }
}
