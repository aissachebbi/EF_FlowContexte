package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;

public final class FlowContext {
    private final String flowName;
    private final String businessTableName;
    private final Map<String, BranchEntry> branchesByCode;

    public FlowContext(String flowName, String businessTableName, Map<String, BranchEntry> branchesByCode) {
        this.flowName = Objects.requireNonNull(flowName, "flowName");
        this.businessTableName = Objects.requireNonNull(businessTableName, "businessTableName");
        this.branchesByCode = Collections.unmodifiableMap(Objects.requireNonNull(branchesByCode, "branchesByCode"));
    }

    public String getFlowName() { return flowName; }
    public String getBusinessTableName() { return businessTableName; }
    public Map<String, BranchEntry> getBranchesByCode() { return branchesByCode; }

    public BranchEntry getBranch(String branchCode) {
        return branchesByCode.get(branchCode);
    }
}

