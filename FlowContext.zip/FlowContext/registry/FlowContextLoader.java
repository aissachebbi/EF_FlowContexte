package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import com.bnpparibas.frmk.easyflow.si.mq2db.dao.ApplicationParameterDao;
import com.bnpparibas.frmk.easyflow.si.mq2db.dao.FileTypeDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlowContextLoader {
    private static final Log LOG = LogFactory.getLog(FlowContextLoader.class);

    private final FileTypeDao fileTypeDao;
    private final ApplicationParameterDao appParamDao;

    public FlowContextLoader(FileTypeDao fileTypeDao, ApplicationParameterDao appParamDao) {
        this.fileTypeDao = fileTypeDao;
        this.appParamDao = appParamDao;
    }

    public FlowContext load(FlowDefinition def) {
        List<FileTypeDao.FileTypeRow> fileTypes =
                fileTypeDao.findActiveByPhysicalPattern(def.getFiletypePhysicalPattern());

        // Vérif: 1 filetype par branch (dans le périmètre du flow/pattern)
        Map<String, Integer> countByBranch = new HashMap<>();
        for (FileTypeDao.FileTypeRow r : fileTypes) {
            countByBranch.merge(r.branchCode, 1, Integer::sum);
        }
        for (Map.Entry<String, Integer> e : countByBranch.entrySet()) {
            if (e.getValue() != 1) {
                throw new IllegalStateException("Flow " + def.getFlowName()
                        + " => branch " + e.getKey()
                        + " has " + e.getValue()
                        + " filetypes for pattern " + def.getFiletypePhysicalPattern());
            }
        }

        Map<String, ApplicationParameterDao.AppParamRow> cfgByBranch =
                appParamDao.loadByKeyPrefix(def.getAppParamKeyPrefix());

        // Option: config par défaut "*"
        ApplicationParameterDao.AppParamRow defaultCfg = cfgByBranch.get("*");

        Map<String, BranchEntry> branches = new HashMap<>();
        for (FileTypeDao.FileTypeRow ft : fileTypes) {
            ApplicationParameterDao.AppParamRow row = cfgByBranch.get(ft.branchCode);
            if (row == null) row = defaultCfg;

            BranchParameters params = BranchParametersParser.parse(row != null ? row.value : null);

            BranchEntry entry = new BranchEntry(
                    ft.branchCode,
                    ft.branchDbId,
                    ft.cbFileTypeDbId,
                    ft.physicalFileType,
                    params
            );
            branches.put(ft.branchCode, entry);
        }

        LOG.info("Loaded FlowContext " + def.getFlowName() + " branches=" + branches.size());
        return new FlowContext(def.getFlowName(), def.getBusinessTableName(), branches);
    }
}
