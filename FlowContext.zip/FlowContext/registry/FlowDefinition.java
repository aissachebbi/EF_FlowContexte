package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import java.util.Objects;

public final class FlowDefinition {
    private final String flowName;
    private final String businessTableName;
    private final String filetypePhysicalPattern;
    private final String appParamKeyPrefix;
    private final boolean enabled;
    private final boolean reloadEnabled;
    private final long versionNum;

    public FlowDefinition(
            String flowName,
            String businessTableName,
            String filetypePhysicalPattern,
            String appParamKeyPrefix,
            boolean enabled,
            boolean reloadEnabled,
            long versionNum
    ) {
        this.flowName = Objects.requireNonNull(flowName, "flowName");
        this.businessTableName = Objects.requireNonNull(businessTableName, "businessTableName");
        this.filetypePhysicalPattern = Objects.requireNonNull(filetypePhysicalPattern, "filetypePhysicalPattern");
        this.appParamKeyPrefix = Objects.requireNonNull(appParamKeyPrefix, "appParamKeyPrefix");
        this.enabled = enabled;
        this.reloadEnabled = reloadEnabled;
        this.versionNum = versionNum;
    }

    public String getFlowName() { return flowName; }
    public String getBusinessTableName() { return businessTableName; }
    public String getFiletypePhysicalPattern() { return filetypePhysicalPattern; }
    public String getAppParamKeyPrefix() { return appParamKeyPrefix; }
    public boolean isEnabled() { return enabled; }
    public boolean isReloadEnabled() { return reloadEnabled; }
    public long getVersionNum() { return versionNum; }
}
