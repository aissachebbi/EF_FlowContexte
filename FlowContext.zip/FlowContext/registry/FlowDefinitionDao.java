package com.bnpparibas.frmk.easyflow.si.mq2db.dao;

import com.bnpparibas.frmk.easyflow.si.mq2db.registry.FlowDefinition;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class FlowDefinitionDao {
    private final JdbcTemplate jdbc;

    public FlowDefinitionDao(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<FlowDefinition> findEnabledFlows() {
        String sql =
                "select FLOW_NAME, BUSINESS_TABLE_NAME, FILETYPE_PHYSICAL_PATTERN, APP_PARAM_KEY_PREFIX, " +
                        "       ENABLED, RELOAD_ENABLED, VERSION_NUM " +
                        "from ACETP.FLOW_DEFINITION " +
                        "where ENABLED = 1";

        return jdbc.query(sql, (rs, rowNum) ->
                new FlowDefinition(
                        rs.getString("FLOW_NAME"),
                        rs.getString("BUSINESS_TABLE_NAME"),
                        rs.getString("FILETYPE_PHYSICAL_PATTERN"),
                        rs.getString("APP_PARAM_KEY_PREFIX"),
                        rs.getInt("ENABLED") == 1,
                        rs.getInt("RELOAD_ENABLED") == 1,
                        rs.getLong("VERSION_NUM")
                )
        );
    }
}
