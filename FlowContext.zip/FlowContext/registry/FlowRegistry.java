package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FlowRegistry {
    private static final Log LOG = LogFactory.getLog(FlowRegistry.class);

    private final FlowContextLoader loader;
    private final Map<String, FlowContext> contextsByFlow = new ConcurrentHashMap<>();

    public FlowRegistry(FlowContextLoader loader) {
        this.loader = loader;
    }

    public FlowContext getRequired(String flowName) {
        FlowContext ctx = contextsByFlow.get(flowName);
        if (ctx == null) throw new IllegalStateException("No FlowContext loaded for flow=" + flowName);
        return ctx;
    }

    public Map<String, FlowContext> snapshot() {
        return Collections.unmodifiableMap(new HashMap<>(contextsByFlow));
    }

    public void put(FlowContext ctx) {
        contextsByFlow.put(ctx.getFlowName(), ctx);
    }

    public void reload(FlowDefinition def) {
        LOG.info("Reloading flow=" + def.getFlowName());
        FlowContext newCtx = loader.load(def);
        contextsByFlow.put(def.getFlowName(), newCtx);
    }
}
