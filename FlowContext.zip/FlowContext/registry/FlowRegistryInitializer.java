package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import com.bnpparibas.frmk.easyflow.si.mq2db.dao.FlowDefinitionDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;

import java.util.List;

public class FlowRegistryInitializer implements SmartInitializingSingleton {
    private static final Log LOG = LogFactory.getLog(FlowRegistryInitializer.class);

    private final FlowDefinitionDao flowDefinitionDao;
    private final FlowRegistry registry;
    private final FlowContextLoader loader;

    public FlowRegistryInitializer(FlowDefinitionDao flowDefinitionDao, FlowRegistry registry, FlowContextLoader loader) {
        this.flowDefinitionDao = flowDefinitionDao;
        this.registry = registry;
        this.loader = loader;
    }

    @Override
    public void afterSingletonsInstantiated() {
        List<FlowDefinition> defs = flowDefinitionDao.findEnabledFlows();
        for (FlowDefinition def : defs) {
            FlowContext ctx = loader.load(def);
            registry.put(ctx);
        }
        LOG.info("FlowRegistry initialized: flows=" + defs.size());
    }
}
