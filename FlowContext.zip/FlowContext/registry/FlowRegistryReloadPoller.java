package com.bnpparibas.frmk.easyflow.si.mq2db.registry;

import com.bnpparibas.frmk.easyflow.si.mq2db.dao.ApplicationParameterDao;
import com.bnpparibas.frmk.easyflow.si.mq2db.dao.FlowDefinitionDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class FlowRegistryReloadPoller {
    private static final Log LOG = LogFactory.getLog(FlowRegistryReloadPoller.class);

    private final ScheduledExecutorService scheduler;
    private final long delayMs;

    private final FlowDefinitionDao flowDefinitionDao;
    private final ApplicationParameterDao appParamDao;
    private final FlowRegistry registry;

    private final Map<String, ApplicationParameterDao.Fingerprint> lastFpByFlow = new ConcurrentHashMap<>();

    public FlowRegistryReloadPoller(
            ScheduledExecutorService scheduler,
            long delayMs,
            FlowDefinitionDao flowDefinitionDao,
            ApplicationParameterDao appParamDao,
            FlowRegistry registry
    ) {
        this.scheduler = scheduler;
        this.delayMs = delayMs;
        this.flowDefinitionDao = flowDefinitionDao;
        this.appParamDao = appParamDao;
        this.registry = registry;
    }

    public void start() {
        if (delayMs <= 0) {
            LOG.info("FlowRegistryReloadPoller disabled (delayMs <= 0)");
            return;
        }
        scheduler.scheduleWithFixedDelay(this::tickSafe, delayMs, delayMs, TimeUnit.MILLISECONDS);
        LOG.info("FlowRegistryReloadPoller started delayMs=" + delayMs);
    }

    private void tickSafe() {
        try {
            tick();
        } catch (Exception e) {
            LOG.error("FlowRegistryReloadPoller tick failed", e);
        }
    }

    private void tick() {
        List<FlowDefinition> defs = flowDefinitionDao.findEnabledFlows();
        for (FlowDefinition def : defs) {
            if (!def.isReloadEnabled()) continue;

            ApplicationParameterDao.Fingerprint fp = appParamDao.fingerprint(def.getAppParamKeyPrefix());
            ApplicationParameterDao.Fingerprint prev = lastFpByFlow.putIfAbsent(def.getFlowName(), fp);

            if (prev == null) {
                LOG.info("Initial fingerprint flow=" + def.getFlowName() + " v=" + fp.maxVersion + " last=" + fp.lastChange);
                continue;
            }

            if (hasChanged(prev, fp)) {
                LOG.info("Config changed flow=" + def.getFlowName()
                        + " prev(v=" + prev.maxVersion + ", last=" + prev.lastChange + ")"
                        + " new(v=" + fp.maxVersion + ", last=" + fp.lastChange + ")");
                registry.reload(def);
                lastFpByFlow.put(def.getFlowName(), fp);
            }
        }
    }

    private boolean hasChanged(ApplicationParameterDao.Fingerprint a, ApplicationParameterDao.Fingerprint b) {
        if (a.maxVersion != b.maxVersion) return true;

        Instant la = a.lastChange != null ? a.lastChange : Instant.EPOCH;
        Instant lb = b.lastChange != null ? b.lastChange : Instant.EPOCH;
        return !la.equals(lb);
    }
}
