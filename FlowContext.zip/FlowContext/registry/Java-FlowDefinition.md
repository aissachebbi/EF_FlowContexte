# Documentation Technique : Classe Java FlowDefinition

Ce document décrit la classe Java `FlowDefinition`, qui est la représentation en mémoire de la table `ACETP.FLOW_DEFINITION`. Elle constitue le socle du modèle de données pour le **Flow Registry**.

---

## 1. Objectif

La classe `FlowDefinition` est un objet de type **Value Object** (immuable) utilisé pour transporter les paramètres de configuration globaux d'un flux depuis la base de données vers le moteur de traitement.

---

## 2. Mapping Base de Données

Chaque instance de `FlowDefinition` correspond à une ligne de la table `ACETP.FLOW_DEFINITION`.

| Champ Java | Type Java | Colonne SQL | Description |
| :--- | :--- | :--- | :--- |
| `flowName` | `String` | `FLOW_NAME` | Identifiant unique du flux. |
| `businessTableName` | `String` | `BUSINESS_TABLE_NAME` | Table cible pour l'insertion des données. |
| `filetypePhysicalPattern` | `String` | `FILETYPE_PHYSICAL_PATTERN` | Pattern (LIKE) pour identifier les fichiers. |
| `appParamKeyPrefix` | `String` | `APP_PARAM_KEY_PREFIX` | Préfixe pour retrouver les paramètres spécifiques. |
| `enabled` | `boolean` | `ENABLED` | Statut d'activation (1=true, 0=false). |
| `reloadEnabled` | `boolean` | `RELOAD_ENABLED` | Autorise le Hot Reload (1=true, 0=false). |
| `versionNum` | `long` | `VERSION_NUM` | Version pour la détection de changements. |

---

## 3. Détails d'Implémentation

### Immuabilité et Sécurité
- La classe est déclarée `final`.
- Tous les champs sont `private final`.
- La validation des entrées est effectuée dans le constructeur via `Objects.requireNonNull()`.

### Constructeur
Le constructeur centralise la création de l'objet et garantit son intégrité :
```java
public FlowDefinition(
        String flowName,
        String businessTableName,
        String filetypePhysicalPattern,
        String appParamKeyPrefix,
        boolean enabled,
        boolean reloadEnabled,
        long versionNum
) {
    this.flowName = Objects.requireNonNull(flowName, "flowName");
    this.businessTableName = Objects.requireNonNull(businessTableName, "businessTableName");
    // ... validation des autres champs obligatoires
}
```

---

## 4. Cycle de Vie dans le Registry

1. **Chargement** : Le `FlowDefinitionDao` exécute une requête `SELECT` sur `ACETP.FLOW_DEFINITION`.
2. **Instanciation** : Pour chaque ligne, un objet `FlowDefinition` est créé.
3. **Indexation** : Les objets sont stockés dans le `FlowRegistry` (Map indexée par `flowName`).
4. **Utilisation** : Le `FlowContextLoader` utilise ces définitions pour charger les contextes spécifiques (branches, types de fichiers).

---

## 5. Relation avec les autres Documents

- Pour le schéma SQL complet : voir [DB1-Table ACETP.FLOW_DEFINITION.md](./DB1-Table%20ACETP.FLOW_DEFINITION.md).
- Pour les règles de parsing des paramètres : voir [Conventions de parsing du champ APPLICATION_PARAMETER.VALUE.md](./Conventions%20de%20parsing%20du%20champ%20APPLICATION_PARAMETER.VALUE.md).
