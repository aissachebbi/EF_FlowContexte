package com.bnpparibas.frmk.easyflow.si.mq2db.config;

import com.bnpparibas.frmk.easyflow.si.mq2db.dao.ApplicationParameterDao;
import com.bnpparibas.frmk.easyflow.si.mq2db.dao.FileTypeDao;
import com.bnpparibas.frmk.easyflow.si.mq2db.dao.FlowDefinitionDao;
import com.bnpparibas.frmk.easyflow.si.mq2db.registry.FlowContextLoader;
import com.bnpparibas.frmk.easyflow.si.mq2db.registry.FlowRegistry;
import com.bnpparibas.frmk.easyflow.si.mq2db.registry.FlowRegistryInitializer;
import com.bnpparibas.frmk.easyflow.si.mq2db.registry.FlowRegistryReloadPoller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@Configuration
public class Mq2DbFlowRegistryConfig {

    @Bean
    public JdbcTemplate mq2dbJdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    public FlowDefinitionDao flowDefinitionDao(JdbcTemplate mq2dbJdbcTemplate) {
        return new FlowDefinitionDao(mq2dbJdbcTemplate);
    }

    @Bean
    public ApplicationParameterDao applicationParameterDao(JdbcTemplate mq2dbJdbcTemplate) {
        return new ApplicationParameterDao(mq2dbJdbcTemplate);
    }

    @Bean
    public FileTypeDao fileTypeDao(JdbcTemplate mq2dbJdbcTemplate) {
        return new FileTypeDao(mq2dbJdbcTemplate);
    }

    @Bean
    public FlowContextLoader flowContextLoader(FileTypeDao fileTypeDao, ApplicationParameterDao applicationParameterDao) {
        return new FlowContextLoader(fileTypeDao, applicationParameterDao);
    }

    @Bean
    public FlowRegistry flowRegistry(FlowContextLoader loader) {
        return new FlowRegistry(loader);
    }

    @Bean
    public FlowRegistryInitializer flowRegistryInitializer(
            FlowDefinitionDao flowDefinitionDao,
            FlowRegistry registry,
            FlowContextLoader loader
    ) {
        return new FlowRegistryInitializer(flowDefinitionDao, registry, loader);
    }

    @Bean(destroyMethod = "shutdown")
    public ScheduledExecutorService flowRegistryScheduler(
            @Value("${mq2db.flowRegistry.pollerThreads:1}") int threads
    ) {
        return Executors.newScheduledThreadPool(Math.max(1, threads));
    }

    @Bean(initMethod = "start")
    public FlowRegistryReloadPoller flowRegistryReloadPoller(
            ScheduledExecutorService flowRegistryScheduler,
            @Value("${mq2db.flowRegistry.reloadPollerDelayMs:60000}") long delayMs,
            FlowDefinitionDao flowDefinitionDao,
            ApplicationParameterDao applicationParameterDao,
            FlowRegistry flowRegistry
    ) {
        return new FlowRegistryReloadPoller(
                flowRegistryScheduler,
                delayMs,
                flowDefinitionDao,
                applicationParameterDao,
                flowRegistry
        );
    }
}
