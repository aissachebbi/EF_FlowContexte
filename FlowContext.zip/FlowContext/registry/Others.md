# Guide d'implémentation du Flow Registry (MQ2DB)

Ce document détaille les étapes de configuration et de mise en œuvre du mécanisme de **Flow Registry** pour le module MQ2DB. Ce système permet une gestion dynamique des flux (JDBC) avec support du **Hot Reload** sans dépendre de Spring Boot ou JPA.

---

## 1. Configuration Spring (XML)

Pour activer la configuration Java dans votre contexte Spring XML (ex: `default-easyflows.xml`), vous devez déclarer le bean de configuration.

### Actions à effectuer :
1. Assurez-vous d'activer la détection des annotations.
2. Déclarez le bean `Mq2DbFlowRegistryConfig`.

```xml
<!-- Activation du scan des annotations pour la configuration Java -->
<context:annotation-config/>

<!-- Déclaration du bean de configuration pour le Flow Registry -->
<bean class="com.bnpparibas.frmk.easyflow.si.mq2db.config.Mq2DbFlowRegistryConfig"/>
```

> **Note :** Si votre XML utilise déjà des résolutions de variables `${...}`, un `PropertyPlaceholderConfigurer` est probablement déjà actif.

---

## 2. Configuration des Propriétés

Ajoutez les paramètres suivants dans votre fichier `.properties` de l'application (ex: `ef.properties`) pour configurer le poller de rechargement.

| Propriété | Valeur recommandée | Description |
| :--- | :--- | :--- |
| `mq2db.flowRegistry.reloadPollerDelayMs` | `60000` | Délai entre deux scans (ms). Si `<= 0`, le hot reload est désactivé. |
| `mq2db.flowRegistry.pollerThreads` | `1` | Nombre de threads dédiés au poller. Généralement, `1` suffit. |

---

## 3. Stratégie de Versionnement (Base de Données)

Le mécanisme de détection des changements repose sur le champ `VERSION_NUM` et les dates de mise à jour.

### Recommandations pour l'incrémentation :
Deux approches sont possibles pour garantir la détection par le poller :

*   **Option A (Trigger DB) :** Créer un trigger sur la table qui incrémente `version_num` et met à jour `updating_date = SYSDATE` à chaque modification.
*   **Option B (Application) :** Gérer l'incrémentation directement dans la requête SQL de mise à jour :
    ```sql
    UPDATE APPLICATION_PARAMETER 
    SET VALUE = ?, VERSION_NUM = VERSION_NUM + 1, UPDATING_DATE = SYSDATE 
    WHERE ...
    ```

**Fonctionnement du Poller :** Il utilise `max(VERSION_NUM)` et `max(UPDATING_DATE)` pour détecter tout changement, même si l'un des deux mécanismes est défaillant.

---

## 4. Fonctionnement du Hot Reload

Le cycle de vie du rechargement à chaque "tick" du poller est le suivant :

1.  **Scan :** Lecture de la table `FLOW_DEFINITION` pour identifier les flux actifs (`ENABLED=1`).
2.  **Vérification :** Pour chaque flux avec `RELOAD_ENABLED=1`, calcul du *fingerprint* sur `APPLICATION_PARAMETER` par préfixe.
3.  **Action :** Si le fingerprint est différent :
    *   Rechargement des patterns `CB_FILE_TYPE`.
    *   Rechargement des paramètres `APPLICATION_PARAMETER`.
    *   Substitution à chaud du `FlowContext` en mémoire.

---

## 5. Checklist de Développement (Structure du Module)

### Localisation : `src/main/java/com/bnpparibas/frmk/easyflow/si/mq2db/`

#### Registry & Core
*   `registry/FlowDefinition.java` (Modèle)
*   `registry/BranchParameters.java`
*   `registry/BranchParametersParser.java`
*   `registry/BranchEntry.java`
*   `registry/FlowContext.java`
*   `registry/FlowContextLoader.java`
*   `registry/FlowRegistry.java`
*   `registry/FlowRegistryInitializer.java`
*   `registry/FlowRegistryReloadPoller.java`

#### Couche d'Accès aux Données (DAO)
*   `dao/FlowDefinitionDao.java`
*   `dao/FileTypeDao.java`
*   `dao/ApplicationParameterDao.java`

#### Configuration
*   `config/Mq2DbFlowRegistryConfig.java`

#### Ressources SQL
*   `src/main/resources/sql/flow_definition.sql` :
    *   DDL pour `ACETP.FLOW_DEFINITION`.
    *   Insert pour `MTMIN` (ex: `app_param_key_prefix=EZF_MQ2FILE_FLUSH_MTMIN_`).

---

## 6. Livraison

**Message de commit type :**
`"Add JDBC Flow Registry with hot reload poller"`
